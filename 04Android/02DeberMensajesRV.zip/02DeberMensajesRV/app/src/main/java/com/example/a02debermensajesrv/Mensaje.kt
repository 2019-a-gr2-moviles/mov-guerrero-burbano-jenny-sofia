package com.example.a02debermensajesrv

class Mensaje (var contacto: String, var numeroMensajes: Int, var contenidoMensaje: String, var favorito: Boolean){

}
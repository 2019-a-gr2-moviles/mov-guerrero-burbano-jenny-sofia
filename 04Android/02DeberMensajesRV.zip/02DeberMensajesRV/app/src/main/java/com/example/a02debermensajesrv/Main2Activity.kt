package com.example.a02debermensajesrv

import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity;

import kotlinx.android.synthetic.main.activity_main2.*

class Main2Activity : AppCompatActivity() {


}
